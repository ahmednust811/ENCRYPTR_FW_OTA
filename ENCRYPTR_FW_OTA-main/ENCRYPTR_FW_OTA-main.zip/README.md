# ENCRYPTR_FW_OTA
# initial code update : 13/05/2022 basic OTA task created